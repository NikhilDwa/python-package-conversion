from setuptools import setup
setup(
    name="conversion",
    version="0.1",
    description="This is a package to convert your input numbers.",
    author="Nikhil",
    package=['conversion'],
    install_requires=[])
